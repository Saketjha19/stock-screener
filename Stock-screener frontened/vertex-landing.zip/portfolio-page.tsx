"use client"

import { useState } from "react"
import { Search, TrendingUp, TrendingDown, RefreshCw, Download, Menu, X, ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

interface Stock {
  symbol: string
  name: string
  quantity: number
  purchasePrice: number
  livePrice: number
  purchaseDate: string
  sector: string
}

interface MarketData {
  name: string
  value: string
  change: number
}

interface NewsItem {
  headline: string
  timestamp: string
}

export default function PortfolioPage() {
  const [stocks, setStocks] = useState<Stock[]>([
    {
      symbol: "GPC",
      name: "Genuine Parts",
      quantity: 10,
      purchasePrice: 137.18,
      livePrice: 137.18,
      purchaseDate: "11/08/2024",
      sector: "Auto",
    },
    {
      symbol: "AAPL",
      name: "Apple Inc.",
      quantity: 10,
      purchasePrice: 216.24,
      livePrice: 216.24,
      purchaseDate: "10/15/2024",
      sector: "Tech",
    },
    {
      symbol: "MSFT",
      name: "Microsoft Corp.",
      quantity: 15,
      purchasePrice: 378.5,
      livePrice: 380.25,
      purchaseDate: "09/22/2024",
      sector: "Tech",
    },
    {
      symbol: "TSLA",
      name: "Tesla Inc.",
      quantity: 5,
      purchasePrice: 248.42,
      livePrice: 245.8,
      purchaseDate: "11/01/2024",
      sector: "Auto",
    },
    {
      symbol: "XOM",
      name: "Exxon Mobil",
      quantity: 20,
      purchasePrice: 118.75,
      livePrice: 121.3,
      purchaseDate: "10/08/2024",
      sector: "Energy",
    },
  ])

  const [marketData] = useState<MarketData[]>([
    { name: "S&P 500", value: "4,800", change: 0.8 },
    { name: "Dow Jones", value: "38,200", change: -0.3 },
    { name: "NASDAQ", value: "15,300", change: 1.2 },
  ])

  const [newsItems] = useState<NewsItem[]>([
    { headline: "Tech Stocks Surge Amid AI Optimism", timestamp: "15 mins ago" },
    { headline: "Federal Reserve Holds Interest Rates Steady", timestamp: "1 hour ago" },
    { headline: "Energy Sector Shows Strong Q3 Earnings", timestamp: "2 hours ago" },
  ])

  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [modalType, setModalType] = useState<"buy" | "sell">("buy")
  const [selectedStock, setSelectedStock] = useState<Stock | null>(null)
  const [orderType, setOrderType] = useState("Market")
  const [quantity, setQuantity] = useState(10)
  const [limitPrice, setLimitPrice] = useState("")
  const [expandedRow, setExpandedRow] = useState<string | null>(null)
  const [sortField, setSortField] = useState<keyof Stock | null>(null)
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc")
  const [filter, setFilter] = useState("All")
  const [showToast, setShowToast] = useState(false)
  const [toastMessage, setToastMessage] = useState("")
  const [activeNav, setActiveNav] = useState("Portfolio")

  const calculateProfitLoss = (stock: Stock) => {
    return (stock.livePrice - stock.purchasePrice) * stock.quantity
  }

  const calculateTotalValue = () => {
    return stocks.reduce((total, stock) => total + stock.livePrice * stock.quantity, 0)
  }

  const calculateTotalProfitLoss = () => {
    return stocks.reduce((total, stock) => total + calculateProfitLoss(stock), 0)
  }

  const refreshPrices = () => {
    setStocks((prevStocks) =>
      prevStocks.map((stock) => ({
        ...stock,
        livePrice: stock.livePrice * (1 + (Math.random() - 0.5) * 0.02), // ±1% change
      })),
    )
    showToastMessage("Prices refreshed successfully!")
  }

  const showToastMessage = (message: string) => {
    setToastMessage(message)
    setShowToast(true)
    setTimeout(() => setShowToast(false), 3000)
  }

  const handleBuySell = (stock: Stock, type: "buy" | "sell") => {
    setSelectedStock(stock)
    setModalType(type)
    setIsModalOpen(true)
    setQuantity(10)
    setLimitPrice("")
    setOrderType("Market")
  }

  const confirmTransaction = () => {
    if (!selectedStock) return

    if (modalType === "buy") {
      setStocks((prevStocks) =>
        prevStocks.map((stock) =>
          stock.symbol === selectedStock.symbol
            ? {
                ...stock,
                quantity: stock.quantity + quantity,
                purchasePrice:
                  (stock.purchasePrice * stock.quantity + selectedStock.livePrice * quantity) /
                  (stock.quantity + quantity),
              }
            : stock,
        ),
      )
      showToastMessage(`Successfully bought ${quantity} shares of ${selectedStock.symbol}`)
    } else {
      setStocks((prevStocks) =>
        prevStocks.map((stock) =>
          stock.symbol === selectedStock.symbol
            ? { ...stock, quantity: Math.max(0, stock.quantity - quantity) }
            : stock,
        ),
      )
      showToastMessage(`Successfully sold ${quantity} shares of ${selectedStock.symbol}`)
    }

    setIsModalOpen(false)
  }

  const handleSort = (field: keyof Stock) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }

  const filteredAndSortedStocks = () => {
    let filtered = stocks
    if (filter !== "All") {
      filtered = stocks.filter((stock) => stock.sector === filter)
    }

    if (sortField) {
      filtered.sort((a, b) => {
        let aValue = a[sortField]
        let bValue = b[sortField]

        if (sortField === "livePrice" || sortField === "purchasePrice") {
          aValue = Number(aValue)
          bValue = Number(bValue)
        }

        if (aValue < bValue) return sortDirection === "asc" ? -1 : 1
        if (aValue > bValue) return sortDirection === "asc" ? 1 : -1
        return 0
      })
    }

    return filtered
  }

  const exportToCSV = () => {
    const headers = ["Symbol", "Name", "Quantity", "Purchase Price", "Live Price", "Profit/Loss"]
    const csvContent = [
      headers.join(","),
      ...stocks.map((stock) =>
        [
          stock.symbol,
          stock.name,
          stock.quantity,
          stock.purchasePrice.toFixed(2),
          stock.livePrice.toFixed(2),
          calculateProfitLoss(stock).toFixed(2),
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "portfolio.csv"
    a.click()
    window.URL.revokeObjectURL(url)
    showToastMessage("Portfolio exported to CSV successfully!")
  }

  const totalProfitLoss = calculateTotalProfitLoss()

  return (
    <div className="min-h-screen bg-[#1B263B] text-white font-sans">
      {/* Header */}
      <header className="bg-[#1B263B] border-b border-[#344266] p-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="text-2xl font-bold text-[#FFD700]">TradeRiser</div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-white hover:text-[#FFD700]"
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          >
            {isSidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-6">
            {["Portfolio", "Watchlist", "Markets", "Settings"].map((item) => (
              <Button
                key={item}
                variant="ghost"
                className={`text-white hover:text-[#FFD700] transition-colors ${
                  activeNav === item ? "text-[#FFD700]" : ""
                }`}
                onClick={() => setActiveNav(item)}
              >
                {item}
              </Button>
            ))}
          </nav>
        </div>

        {/* Balance Card */}
        <Card className="mt-4 bg-[#2A3550] border-[#FFD700] border-opacity-30">
          <CardContent className="p-4 text-center">
            <div className="flex flex-col md:flex-row justify-center items-center space-y-2 md:space-y-0 md:space-x-8">
              <div>
                <span className="text-[#4681F4] text-lg font-semibold">Total Balance: </span>
                <span className="text-white text-xl font-bold">${calculateTotalValue().toLocaleString()}</span>
              </div>
              <div>
                <span className="text-white text-lg font-semibold">Total Profit/Loss: </span>
                <span className={`text-xl font-bold ${totalProfitLoss >= 0 ? "text-green-500" : "text-red-500"}`}>
                  ${totalProfitLoss >= 0 ? "+" : ""}
                  {totalProfitLoss.toLocaleString()}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`${
            isSidebarOpen ? "translate-x-0" : "-translate-x-full"
          } md:translate-x-0 fixed md:relative z-30 w-80 md:w-1/4 h-screen bg-[#2A3550] border-r border-[#344266] p-4 transition-transform duration-300 ease-in-out overflow-y-auto`}
        >
          {/* Search Bar */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search Stocks"
                className="pl-10 bg-[#1B263B] border-[#344266] text-white placeholder-gray-400 focus:border-[#FFD700]"
              />
            </div>
          </div>

          {/* Market Summary */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-4 text-[#FFD700]">Market Summary</h3>
            <div className="space-y-3">
              {marketData.map((market, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-[#1B263B] rounded-lg">
                  <div>
                    <div className="text-white font-medium">{market.name}</div>
                    <div className="text-gray-300">{market.value}</div>
                  </div>
                  <div className={`flex items-center ${market.change >= 0 ? "text-green-500" : "text-red-500"}`}>
                    {market.change >= 0 ? (
                      <TrendingUp className="w-4 h-4 mr-1" />
                    ) : (
                      <TrendingDown className="w-4 h-4 mr-1" />
                    )}
                    <span className="text-sm">{Math.abs(market.change)}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* News Feed */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-[#FFD700]">Latest News</h3>
            <div className="space-y-3">
              {newsItems.map((news, index) => (
                <div key={index} className="p-3 bg-[#1B263B] rounded-lg">
                  <div className="text-white text-sm font-medium mb-1">{news.headline}</div>
                  <div className="text-gray-400 text-xs">{news.timestamp}</div>
                </div>
              ))}
            </div>
          </div>
        </aside>

        {/* Overlay for mobile */}
        {isSidebarOpen && (
          <div
            className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 p-6 overflow-x-auto">
          {/* Title and Controls */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 space-y-4 md:space-y-0">
            <h1 className="text-2xl font-bold text-white">Your Portfolio</h1>
            <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
              <Select value={filter} onValueChange={setFilter}>
                <SelectTrigger className="w-32 bg-[#2A3550] border-[#344266] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#2A3550] border-[#344266] text-white">
                  <SelectItem value="All">All</SelectItem>
                  <SelectItem value="Tech">Tech</SelectItem>
                  <SelectItem value="Energy">Energy</SelectItem>
                  <SelectItem value="Auto">Auto</SelectItem>
                </SelectContent>
              </Select>
              <Button
                onClick={refreshPrices}
                className="bg-[#FFD700] text-black hover:bg-[#FFD700]/90 transition-all duration-200 hover:shadow-lg hover:shadow-[#FFD700]/20"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>

          {/* Portfolio Table */}
          <div className="bg-[#2A3550] rounded-lg border border-[#FFD700] border-opacity-30 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-[#1B263B]">
                  <tr>
                    {[
                      { key: "symbol", label: "Symbol" },
                      { key: "name", label: "Name" },
                      { key: "quantity", label: "Qty" },
                      { key: "purchasePrice", label: "Purchase Price" },
                      { key: "livePrice", label: "Live Price" },
                      { key: null, label: "Profit/Loss" },
                      { key: null, label: "Actions" },
                    ].map((column, index) => (
                      <th
                        key={index}
                        className={`px-4 py-3 text-left text-white font-semibold ${
                          column.key ? "cursor-pointer hover:text-[#FFD700]" : ""
                        }`}
                        onClick={() => column.key && handleSort(column.key as keyof Stock)}
                      >
                        <div className="flex items-center">
                          {column.label}
                          {column.key && sortField === column.key && (
                            <span className="ml-1">
                              {sortDirection === "asc" ? (
                                <ChevronUp className="w-4 h-4" />
                              ) : (
                                <ChevronDown className="w-4 h-4" />
                              )}
                            </span>
                          )}
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredAndSortedStocks().map((stock, index) => (
                    <>
                      <tr
                        key={stock.symbol}
                        className={`${
                          index % 2 === 0 ? "bg-[#2A3550]" : "bg-[#344266]"
                        } hover:bg-[#344266] hover:bg-opacity-70 transition-colors cursor-pointer`}
                        onClick={() => setExpandedRow(expandedRow === stock.symbol ? null : stock.symbol)}
                      >
                        <td className="px-4 py-3 text-white font-semibold">{stock.symbol}</td>
                        <td className="px-4 py-3 text-white">{stock.name}</td>
                        <td className="px-4 py-3 text-white">{stock.quantity}</td>
                        <td className="px-4 py-3 text-white">${stock.purchasePrice.toFixed(2)}</td>
                        <td className="px-4 py-3 text-white">${stock.livePrice.toFixed(2)}</td>
                        <td
                          className={`px-4 py-3 font-semibold ${
                            calculateProfitLoss(stock) >= 0 ? "text-green-500" : "text-red-500"
                          }`}
                        >
                          ${calculateProfitLoss(stock) >= 0 ? "+" : ""}
                          {calculateProfitLoss(stock).toFixed(2)}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation()
                                handleBuySell(stock, "buy")
                              }}
                              className="bg-[#4681F4] hover:bg-[#4681F4]/90 text-white transition-all duration-200 hover:shadow-lg hover:shadow-[#4681F4]/20"
                            >
                              Buy More
                            </Button>
                            <Button
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation()
                                handleBuySell(stock, "sell")
                              }}
                              className="bg-[#F44336] hover:bg-[#F44336]/90 text-white transition-all duration-200 hover:shadow-lg hover:shadow-[#F44336]/20"
                            >
                              Sell
                            </Button>
                          </div>
                        </td>
                      </tr>
                      {expandedRow === stock.symbol && (
                        <tr className="bg-[#1B263B]">
                          <td colSpan={7} className="px-4 py-3">
                            <div className="text-gray-300">
                              <strong>Purchase Date:</strong> {stock.purchaseDate} | <strong>Sector:</strong>{" "}
                              {stock.sector} | <strong>Total Value:</strong> $
                              {(stock.livePrice * stock.quantity).toFixed(2)}
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Export Button */}
          <div className="mt-6 flex justify-end">
            <Button
              onClick={exportToCSV}
              variant="outline"
              className="border-[#FFD700] text-[#FFD700] hover:bg-[#FFD700] hover:text-black transition-all duration-200"
            >
              <Download className="w-4 h-4 mr-2" />
              Export to CSV
            </Button>
          </div>
        </main>
      </div>

      {/* Buy/Sell Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="bg-[#2A3550] border-[#344266] text-white">
          <DialogHeader>
            <DialogTitle className="text-[#FFD700]">
              {modalType === "buy" ? "Buy More" : "Sell"} {selectedStock?.symbol}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="orderType" className="text-white">
                Order Type
              </Label>
              <Select value={orderType} onValueChange={setOrderType}>
                <SelectTrigger className="bg-[#1B263B] border-[#344266] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#1B263B] border-[#344266] text-white">
                  <SelectItem value="Market">Market</SelectItem>
                  <SelectItem value="Limit">Limit</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="quantity" className="text-white">
                Quantity
              </Label>
              <Input
                id="quantity"
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="bg-[#1B263B] border-[#344266] text-white"
              />
            </div>
            {orderType === "Limit" && (
              <div>
                <Label htmlFor="limitPrice" className="text-white">
                  Limit Price
                </Label>
                <Input
                  id="limitPrice"
                  type="number"
                  step="0.01"
                  value={limitPrice}
                  onChange={(e) => setLimitPrice(e.target.value)}
                  className="bg-[#1B263B] border-[#344266] text-white"
                  placeholder="Enter limit price"
                />
              </div>
            )}
            <div className="flex space-x-4">
              <Button
                onClick={confirmTransaction}
                className="flex-1 bg-[#FFD700] text-black hover:bg-[#FFD700]/90 transition-all duration-200"
              >
                Confirm
              </Button>
              <Button
                onClick={() => setIsModalOpen(false)}
                variant="outline"
                className="flex-1 border-gray-500 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Toast Notification */}
      {showToast && (
        <div className="fixed bottom-4 right-4 bg-[#FFD700] text-black px-6 py-3 rounded-lg shadow-lg z-50 transition-all duration-300">
          {toastMessage}
        </div>
      )}
    </div>
  )
}
