"use client"

import { useState } from "react"
import { TopNavigation } from "./components/top-navigation"
import { LeftSidebar } from "./components/left-sidebar"
import { LiveTicker } from "./components/live-ticker"
import { StockOverview } from "./components/stock-overview"
import { FuturesPanel } from "./components/futures-panel"
import { GainersPanel } from "./components/gainers-panel"
import { PortfolioManager } from "./components/portfolio-manager"

export default function TradingDashboard() {
  const [selectedStock, setSelectedStock] = useState("AAPL")
  const [activeView, setActiveView] = useState("dashboard")

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <TopNavigation activeView={activeView} onViewChange={setActiveView} />

      <div className="flex">
        <LeftSidebar />

        <main className="flex-1 p-6 ml-80">
          {activeView === "dashboard" && (
            <div className="space-y-6">
              <LiveTicker />
              <StockOverview selectedStock={selectedStock} onStockSelect={setSelectedStock} />
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <FuturesPanel />
                <GainersPanel />
              </div>
            </div>
          )}

          {activeView === "portfolio" && <PortfolioManager />}
        </main>
      </div>
    </div>
  )
}
