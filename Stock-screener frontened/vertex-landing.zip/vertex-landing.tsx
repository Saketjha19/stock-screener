import { Navigation } from "./components/navigation"
import { HeroSection } from "./components/hero-section"
import { CrossPlatformSection } from "./components/cross-platform-section"
import { FeaturesSection } from "./components/features-section"
import { Footer } from "./components/footer"

export default function VertexLanding() {
  return (
    <div className="min-h-screen bg-gray-900">
      <Navigation />
      <HeroSection />
      <CrossPlatformSection />
      <FeaturesSection />
      <Footer />
    </div>
  )
}
