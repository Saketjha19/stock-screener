"use client"

import { useState } from "react"
import { PortfolioOverview } from "./portfolio-overview"
import { HoldingsManager } from "./holdings-manager"
import { TransactionHistory } from "./transaction-history"
import { PerformanceAnalytics } from "./performance-analytics"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"

export function PortfolioManager() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-white">Portfolio Management</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-gray-700 border-gray-600">
          <TabsTrigger value="overview" className="data-[state=active]:bg-cyan-600">
            Overview
          </TabsTrigger>
          <TabsTrigger value="holdings" className="data-[state=active]:bg-cyan-600">
            Holdings
          </TabsTrigger>
          <TabsTrigger value="transactions" className="data-[state=active]:bg-cyan-600">
            Transactions
          </TabsTrigger>
          <TabsTrigger value="analytics" className="data-[state=active]:bg-cyan-600">
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <PortfolioOverview />
        </TabsContent>

        <TabsContent value="holdings" className="space-y-6">
          <HoldingsManager />
        </TabsContent>

        <TabsContent value="transactions" className="space-y-6">
          <TransactionHistory />
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <PerformanceAnalytics />
        </TabsContent>
      </Tabs>
    </div>
  )
}
