"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, TrendingUp, TrendingDown, Edit, Trash2 } from "lucide-react"

const holdings = [
  {
    id: 1,
    symbol: "AAPL",
    name: "Apple Inc.",
    shares: 150,
    avgPrice: 165.43,
    currentPrice: 175.43,
    totalValue: 26314.5,
    gainLoss: 1500.0,
    gainLossPercent: 6.04,
  },
  {
    id: 2,
    symbol: "MSFT",
    name: "Microsoft Corp.",
    shares: 80,
    avgPrice: 350.85,
    currentPrice: 378.85,
    totalValue: 30308.0,
    gainLoss: 2240.0,
    gainLossPercent: 7.98,
  },
  {
    id: 3,
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    shares: 120,
    avgPrice: 125.21,
    currentPrice: 138.21,
    totalValue: 16585.2,
    gainLoss: 1560.0,
    gainLossPercent: 10.38,
  },
  {
    id: 4,
    symbol: "NVDA",
    name: "NVIDIA Corp.",
    shares: 60,
    avgPrice: 380.89,
    currentPrice: 432.89,
    totalValue: 25973.4,
    gainLoss: 3120.0,
    gainLossPercent: 13.65,
  },
  {
    id: 5,
    symbol: "TSLA",
    name: "Tesla Inc.",
    shares: 90,
    avgPrice: 235.42,
    currentPrice: 248.42,
    totalValue: 22357.8,
    gainLoss: 1170.0,
    gainLossPercent: 5.52,
  },
]

export function HoldingsManager() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedHolding, setSelectedHolding] = useState<any>(null)

  const handleEdit = (holding: any) => {
    setSelectedHolding(holding)
    setIsEditDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Holdings Management</h2>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600">
              <Plus className="w-4 h-4 mr-2" />
              Add Holding
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-gray-800 border-gray-700 text-white">
            <DialogHeader>
              <DialogTitle>Add New Holding</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="symbol">Stock Symbol</Label>
                <Input id="symbol" placeholder="e.g., AAPL" className="bg-gray-700 border-gray-600 text-white" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="shares">Shares</Label>
                  <Input
                    id="shares"
                    type="number"
                    placeholder="100"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="price">Purchase Price</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    placeholder="150.00"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="date">Purchase Date</Label>
                <Input id="date" type="date" className="bg-gray-700 border-gray-600 text-white" />
              </div>
              <div className="flex space-x-2">
                <Button
                  onClick={() => setIsAddDialogOpen(false)}
                  variant="outline"
                  className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => setIsAddDialogOpen(false)}
                  className="flex-1 bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
                >
                  Add Holding
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Current Holdings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left py-3 px-4 text-gray-300 font-medium">Symbol</th>
                  <th className="text-right py-3 px-4 text-gray-300 font-medium">Shares</th>
                  <th className="text-right py-3 px-4 text-gray-300 font-medium">Avg Price</th>
                  <th className="text-right py-3 px-4 text-gray-300 font-medium">Current Price</th>
                  <th className="text-right py-3 px-4 text-gray-300 font-medium">Total Value</th>
                  <th className="text-right py-3 px-4 text-gray-300 font-medium">Gain/Loss</th>
                  <th className="text-right py-3 px-4 text-gray-300 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {holdings.map((holding) => (
                  <tr key={holding.id} className="border-b border-gray-700 hover:bg-gray-700/50">
                    <td className="py-4 px-4">
                      <div>
                        <div className="font-semibold text-white">{holding.symbol}</div>
                        <div className="text-sm text-gray-400">{holding.name}</div>
                      </div>
                    </td>
                    <td className="text-right py-4 px-4 text-white">{holding.shares}</td>
                    <td className="text-right py-4 px-4 text-white">${holding.avgPrice.toFixed(2)}</td>
                    <td className="text-right py-4 px-4 text-white">${holding.currentPrice.toFixed(2)}</td>
                    <td className="text-right py-4 px-4 text-white">${holding.totalValue.toLocaleString()}</td>
                    <td className="text-right py-4 px-4">
                      <div className={holding.gainLoss >= 0 ? "text-green-400" : "text-red-400"}>
                        <div className="flex items-center justify-end">
                          {holding.gainLoss >= 0 ? (
                            <TrendingUp className="w-3 h-3 mr-1" />
                          ) : (
                            <TrendingDown className="w-3 h-3 mr-1" />
                          )}
                          <span>
                            {holding.gainLoss >= 0 ? "+" : ""}${holding.gainLoss.toFixed(2)}
                          </span>
                        </div>
                        <div className="text-sm">
                          ({holding.gainLoss >= 0 ? "+" : ""}
                          {holding.gainLossPercent.toFixed(2)}%)
                        </div>
                      </div>
                    </td>
                    <td className="text-right py-4 px-4">
                      <div className="flex justify-end space-x-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(holding)}
                          className="text-gray-400 hover:text-white"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-gray-400 hover:text-red-400">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="text-center">
              <TrendingUp className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <h3 className="font-semibold text-white mb-2">Buy More Shares</h3>
              <p className="text-sm text-gray-400 mb-4">Add to existing positions</p>
              <Button className="w-full bg-green-600 hover:bg-green-700">Buy Shares</Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="text-center">
              <TrendingDown className="w-8 h-8 text-red-400 mx-auto mb-2" />
              <h3 className="font-semibold text-white mb-2">Sell Shares</h3>
              <p className="text-sm text-gray-400 mb-4">Reduce or close positions</p>
              <Button className="w-full bg-red-600 hover:bg-red-700">Sell Shares</Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="text-center">
              <Plus className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
              <h3 className="font-semibold text-white mb-2">Rebalance</h3>
              <p className="text-sm text-gray-400 mb-4">Optimize allocation</p>
              <Button className="w-full bg-cyan-600 hover:bg-cyan-700">Rebalance</Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Edit Holding: {selectedHolding?.symbol}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-shares">Shares</Label>
                <Input
                  id="edit-shares"
                  type="number"
                  defaultValue={selectedHolding?.shares}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-price">Average Price</Label>
                <Input
                  id="edit-price"
                  type="number"
                  step="0.01"
                  defaultValue={selectedHolding?.avgPrice}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="action">Action</Label>
              <Select>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue placeholder="Select action" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  <SelectItem value="update">Update holding</SelectItem>
                  <SelectItem value="buy">Buy more shares</SelectItem>
                  <SelectItem value="sell">Sell shares</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex space-x-2">
              <Button
                onClick={() => setIsEditDialogOpen(false)}
                variant="outline"
                className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={() => setIsEditDialogOpen(false)}
                className="flex-1 bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
              >
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
