"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Download, Filter, Search } from "lucide-react"

const transactions = [
  {
    id: 1,
    date: "2024-01-15",
    type: "BUY",
    symbol: "AAPL",
    name: "Apple Inc.",
    shares: 50,
    price: 165.43,
    total: 8271.5,
    fees: 4.99,
  },
  {
    id: 2,
    date: "2024-01-10",
    type: "SELL",
    symbol: "TSLA",
    name: "Tesla Inc.",
    shares: 25,
    price: 245.67,
    total: 6141.75,
    fees: 4.99,
  },
  {
    id: 3,
    date: "2024-01-08",
    type: "BUY",
    symbol: "MSFT",
    name: "Microsoft Corp.",
    shares: 30,
    price: 350.85,
    total: 10525.5,
    fees: 4.99,
  },
  {
    id: 4,
    date: "2024-01-05",
    type: "DIVIDEND",
    symbol: "AAPL",
    name: "Apple Inc.",
    shares: 100,
    price: 0.24,
    total: 24.0,
    fees: 0,
  },
  {
    id: 5,
    date: "2024-01-03",
    type: "BUY",
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    shares: 40,
    price: 125.21,
    total: 5008.4,
    fees: 4.99,
  },
  {
    id: 6,
    date: "2023-12-28",
    type: "BUY",
    symbol: "NVDA",
    name: "NVIDIA Corp.",
    shares: 20,
    price: 380.89,
    total: 7617.8,
    fees: 4.99,
  },
  {
    id: 7,
    date: "2023-12-20",
    type: "SELL",
    symbol: "META",
    name: "Meta Platforms",
    shares: 15,
    price: 298.45,
    total: 4476.75,
    fees: 4.99,
  },
  {
    id: 8,
    date: "2023-12-15",
    type: "BUY",
    symbol: "TSLA",
    name: "Tesla Inc.",
    shares: 65,
    price: 235.42,
    total: 15302.3,
    fees: 4.99,
  },
]

export function TransactionHistory() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [dateRange, setDateRange] = useState("all")

  const filteredTransactions = transactions.filter((transaction) => {
    const matchesSearch =
      transaction.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = filterType === "all" || transaction.type === filterType
    return matchesSearch && matchesType
  })

  const getTypeColor = (type: string) => {
    switch (type) {
      case "BUY":
        return "bg-green-600"
      case "SELL":
        return "bg-red-600"
      case "DIVIDEND":
        return "bg-blue-600"
      default:
        return "bg-gray-600"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Transaction History</h2>
        <Button className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600">
          <Download className="w-4 h-4 mr-2" />
          Export
        </Button>
      </div>

      {/* Filters */}
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search symbol or company..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Transaction Type" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="BUY">Buy</SelectItem>
                <SelectItem value="SELL">Sell</SelectItem>
                <SelectItem value="DIVIDEND">Dividend</SelectItem>
              </SelectContent>
            </Select>
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Date Range" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="7d">Last 7 Days</SelectItem>
                <SelectItem value="30d">Last 30 Days</SelectItem>
                <SelectItem value="90d">Last 90 Days</SelectItem>
                <SelectItem value="1y">Last Year</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
              <Filter className="w-4 h-4 mr-2" />
              More Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Transaction Table */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left py-3 px-4 text-gray-300 font-medium">Date</th>
                  <th className="text-left py-3 px-4 text-gray-300 font-medium">Type</th>
                  <th className="text-left py-3 px-4 text-gray-300 font-medium">Symbol</th>
                  <th className="text-right py-3 px-4 text-gray-300 font-medium">Shares</th>
                  <th className="text-right py-3 px-4 text-gray-300 font-medium">Price</th>
                  <th className="text-right py-3 px-4 text-gray-300 font-medium">Total</th>
                  <th className="text-right py-3 px-4 text-gray-300 font-medium">Fees</th>
                </tr>
              </thead>
              <tbody>
                {filteredTransactions.map((transaction) => (
                  <tr key={transaction.id} className="border-b border-gray-700 hover:bg-gray-700/50">
                    <td className="py-4 px-4 text-gray-300">{new Date(transaction.date).toLocaleDateString()}</td>
                    <td className="py-4 px-4">
                      <Badge className={`${getTypeColor(transaction.type)} text-white`}>{transaction.type}</Badge>
                    </td>
                    <td className="py-4 px-4">
                      <div>
                        <div className="font-semibold text-white">{transaction.symbol}</div>
                        <div className="text-sm text-gray-400">{transaction.name}</div>
                      </div>
                    </td>
                    <td className="text-right py-4 px-4 text-white">{transaction.shares.toLocaleString()}</td>
                    <td className="text-right py-4 px-4 text-white">${transaction.price.toFixed(2)}</td>
                    <td className="text-right py-4 px-4 text-white">${transaction.total.toLocaleString()}</td>
                    <td className="text-right py-4 px-4 text-gray-300">${transaction.fees.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-green-400">
              {transactions.filter((t) => t.type === "BUY").length}
            </div>
            <div className="text-sm text-gray-400">Buy Orders</div>
          </CardContent>
        </Card>
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-red-400">
              {transactions.filter((t) => t.type === "SELL").length}
            </div>
            <div className="text-sm text-gray-400">Sell Orders</div>
          </CardContent>
        </Card>
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-blue-400">
              {transactions.filter((t) => t.type === "DIVIDEND").length}
            </div>
            <div className="text-sm text-gray-400">Dividends</div>
          </CardContent>
        </Card>
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-white">
              ${transactions.reduce((sum, t) => sum + t.fees, 0).toFixed(2)}
            </div>
            <div className="text-sm text-gray-400">Total Fees</div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
