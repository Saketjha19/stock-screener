"use client"

import { Search, Bell, Settings, User } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface TopNavigationProps {
  activeView: string
  onViewChange: (view: string) => void
}

export function TopNavigation({ activeView, onViewChange }: TopNavigationProps) {
  return (
    <nav className="bg-gray-800 border-b border-gray-700 px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center space-x-8">
          <h1 className="text-2xl font-bold text-cyan-400">Vertex</h1>

          {/* Navigation Tabs */}
          <Tabs value={activeView} onValueChange={onViewChange} className="hidden md:block">
            <TabsList className="bg-gray-700 border-gray-600">
              <TabsTrigger value="dashboard" className="data-[state=active]:bg-cyan-600">
                Dashboard
              </TabsTrigger>
              <TabsTrigger value="charting" className="data-[state=active]:bg-cyan-600">
                Charting Tools
              </TabsTrigger>
              <TabsTrigger value="portfolio" className="data-[state=active]:bg-cyan-600">
                Portfolio
              </TabsTrigger>
              <TabsTrigger value="screener" className="data-[state=active]:bg-cyan-600">
                Stock Screener
              </TabsTrigger>
              <TabsTrigger value="analysis" className="data-[state=active]:bg-cyan-600">
                Technical Analysis
              </TabsTrigger>
              <TabsTrigger value="news" className="data-[state=active]:bg-cyan-600">
                Top Stories
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Search and Actions */}
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search US stocks..."
              className="pl-10 w-64 bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:border-cyan-400"
            />
          </div>

          <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white">
            <Bell className="w-5 h-5" />
          </Button>

          <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white">
            <Settings className="w-5 h-5" />
          </Button>

          <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white">
            <User className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </nav>
  )
}
