"use client"

import { TrendingUp, TrendingDown } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const tickerData = [
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    price: 175.43,
    change: 2.34,
    changePercent: 1.35,
  },
  {
    symbol: "NVDA",
    name: "NVIDIA Corp.",
    price: 432.89,
    change: -5.67,
    changePercent: -1.29,
  },
  {
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    price: 138.21,
    change: 1.89,
    changePercent: 1.39,
  },
  {
    symbol: "MSFT",
    name: "Microsoft Corp.",
    price: 378.85,
    change: 4.23,
    changePercent: 1.13,
  },
  {
    symbol: "TSLA",
    name: "Tesla Inc.",
    price: 248.42,
    change: -3.21,
    changePercent: -1.27,
  },
]

export function LiveTicker() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
      {tickerData.map((stock) => (
        <Card
          key={stock.symbol}
          className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors cursor-pointer"
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div>
                <h3 className="font-bold text-white">{stock.symbol}</h3>
                <p className="text-xs text-gray-400 truncate">{stock.name}</p>
              </div>
              {stock.change >= 0 ? (
                <TrendingUp className="w-4 h-4 text-green-400" />
              ) : (
                <TrendingDown className="w-4 h-4 text-red-400" />
              )}
            </div>

            <div className="space-y-1">
              <div className="text-lg font-bold text-white">${stock.price.toFixed(2)}</div>
              <div className={`text-sm flex items-center ${stock.change >= 0 ? "text-green-400" : "text-red-400"}`}>
                <span>
                  {stock.change >= 0 ? "+" : ""}
                  {stock.change.toFixed(2)}
                </span>
                <span className="ml-1">
                  ({stock.changePercent >= 0 ? "+" : ""}
                  {stock.changePercent.toFixed(2)}%)
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
