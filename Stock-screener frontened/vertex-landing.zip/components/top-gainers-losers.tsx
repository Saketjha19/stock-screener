"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { TrendingUp, TrendingDown } from "lucide-react"

const gainersData = [
  {
    symbol: "NVDA",
    name: "NVIDIA Corp.",
    price: 432.89,
    change: 18.45,
    changePercent: 4.45,
  },
  {
    symbol: "AMD",
    name: "Advanced Micro Devices",
    price: 156.78,
    change: 6.23,
    changePercent: 4.14,
  },
  {
    symbol: "TSLA",
    name: "Tesla Inc.",
    price: 248.42,
    change: 9.87,
    changePercent: 4.14,
  },
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    price: 175.43,
    change: 6.34,
    changePercent: 3.75,
  },
  {
    symbol: "MSFT",
    name: "Microsoft Corp.",
    price: 378.85,
    change: 13.23,
    changePercent: 3.62,
  },
]

const losersData = [
  {
    symbol: "META",
    name: "Meta Platforms",
    price: 485.12,
    change: -15.67,
    changePercent: -3.13,
  },
  {
    symbol: "NFLX",
    name: "Netflix Inc.",
    price: 602.34,
    change: -18.45,
    changePercent: -2.97,
  },
  {
    symbol: "AMZN",
    name: "Amazon.com Inc.",
    price: 178.23,
    change: -4.56,
    changePercent: -2.49,
  },
  {
    symbol: "PYPL",
    name: "PayPal Holdings",
    price: 62.45,
    change: -1.34,
    changePercent: -2.1,
  },
  {
    symbol: "INTC",
    name: "Intel Corp.",
    price: 42.67,
    change: -0.89,
    changePercent: -2.04,
  },
]

export function TopGainersLosers() {
  const [activeTab, setActiveTab] = useState("gainers")

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader className="pb-0">
        <CardTitle className="text-white">Market Movers</CardTitle>
      </CardHeader>
      <CardContent className="pt-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-gray-700 border-gray-600 mb-6">
            <TabsTrigger value="gainers" className="data-[state=active]:bg-green-600">
              Top Gainers
            </TabsTrigger>
            <TabsTrigger value="losers" className="data-[state=active]:bg-red-600">
              Top Losers
            </TabsTrigger>
          </TabsList>

          <TabsContent value="gainers" className="space-y-3">
            {gainersData.map((stock, index) => (
              <div
                key={stock.symbol}
                className="flex items-center justify-between p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors cursor-pointer"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                    {index + 1}
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">{stock.symbol}</h4>
                    <p className="text-sm text-gray-400 truncate max-w-32">{stock.name}</p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-bold text-white">${stock.price.toFixed(2)}</div>
                  <div className="text-green-400 text-sm flex items-center">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    <span>
                      +{stock.change.toFixed(2)} (+{stock.changePercent.toFixed(2)}%)
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="losers" className="space-y-3">
            {losersData.map((stock, index) => (
              <div
                key={stock.symbol}
                className="flex items-center justify-between p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors cursor-pointer"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                    {index + 1}
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">{stock.symbol}</h4>
                    <p className="text-sm text-gray-400 truncate max-w-32">{stock.name}</p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-bold text-white">${stock.price.toFixed(2)}</div>
                  <div className="text-red-400 text-sm flex items-center">
                    <TrendingDown className="w-3 h-3 mr-1" />
                    <span>
                      {stock.change.toFixed(2)} ({stock.changePercent.toFixed(2)}%)
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
