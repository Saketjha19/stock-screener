"use client"

import { TrendingUp, Brain, FileText, Globe } from "lucide-react"

export function FeaturesSection() {
  const features = [
    {
      icon: TrendingUp,
      title: "Live Stock Charts",
      description: "Interactive real-time candlestick charts for each stock.",
      gradient: "from-green-400 to-cyan-400",
    },
    {
      icon: Brain,
      title: "Strategy Analyzer",
      description: "Analyze and compare custom trading strategies.",
      gradient: "from-purple-400 to-pink-400",
    },
    {
      icon: FileText,
      title: "Paper Trading",
      description: "Practice trading without risking money.",
      gradient: "from-blue-400 to-cyan-400",
    },
    {
      icon: Globe,
      title: "US & Indian Stocks",
      description: "Dual market support.",
      gradient: "from-orange-400 to-red-400",
    },
  ]

  const scrollToFooter = () => {
    const element = document.getElementById("about")
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  }

  return (
    <section id="features" className="py-20 bg-gradient-to-br from-gray-900 to-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Powerful Features for{" "}
            <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              Smart Trading
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Everything you need to make informed investment decisions
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700 hover:border-gray-600 transition-all duration-300 hover:transform hover:scale-105 group"
            >
              <div
                className={`w-12 h-12 rounded-xl bg-gradient-to-r ${feature.gradient} p-3 mb-4 group-hover:scale-110 transition-transform duration-300`}
              >
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
              <p className="text-gray-300 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button
            onClick={scrollToFooter}
            className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 hover:scale-105"
          >
            Explore All Features
          </button>
        </div>
      </div>
    </section>
  )
}
