"use client"

import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, BarChart, Bar, Tooltip } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { TrendingUp, TrendingDown, Target, Award, BarChart3, PieChartIcon } from "lucide-react"

const performanceData = [
  { month: "Jan", portfolio: 220000, benchmark: 218000 },
  { month: "Feb", portfolio: 225000, benchmark: 222000 },
  { month: "Mar", portfolio: 218000, benchmark: 220000 },
  { month: "Apr", portfolio: 235000, benchmark: 228000 },
  { month: "May", portfolio: 242000, benchmark: 235000 },
  { month: "Jun", portfolio: 245678, benchmark: 238000 },
]

const monthlyReturns = [
  { month: "Jan", returns: 2.3 },
  { month: "Feb", returns: 2.3 },
  { month: "Mar", returns: -3.1 },
  { month: "Apr", returns: 7.8 },
  { month: "May", returns: 3.0 },
  { month: "Jun", returns: 1.5 },
]

const sectorPerformance = [
  { sector: "Technology", allocation: 45, returns: 12.5, color: "#06B6D4" },
  { sector: "Healthcare", allocation: 20, returns: 8.3, color: "#8B5CF6" },
  { sector: "Finance", allocation: 15, returns: 6.7, color: "#10B981" },
  { sector: "Consumer", allocation: 12, returns: 4.2, color: "#F59E0B" },
  { sector: "Energy", allocation: 8, returns: -2.1, color: "#EF4444" },
]

const riskMetrics = {
  sharpeRatio: 1.24,
  beta: 1.08,
  volatility: 18.5,
  maxDrawdown: -8.2,
  alpha: 2.3,
  informationRatio: 0.85,
}

export function PerformanceAnalytics() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Performance Analytics</h2>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="bg-gray-700 border-gray-600">
          <TabsTrigger value="overview" className="data-[state=active]:bg-cyan-600">
            Overview
          </TabsTrigger>
          <TabsTrigger value="returns" className="data-[state=active]:bg-cyan-600">
            Returns
          </TabsTrigger>
          <TabsTrigger value="risk" className="data-[state=active]:bg-cyan-600">
            Risk Analysis
          </TabsTrigger>
          <TabsTrigger value="sectors" className="data-[state=active]:bg-cyan-600">
            Sector Analysis
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Performance Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Total Return</CardTitle>
                <TrendingUp className="h-4 w-4 text-green-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-400">+11.67%</div>
                <p className="text-xs text-gray-400">Since inception</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Annualized Return</CardTitle>
                <Award className="h-4 w-4 text-cyan-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-cyan-400">14.2%</div>
                <p className="text-xs text-gray-400">vs 11.8% benchmark</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Sharpe Ratio</CardTitle>
                <Target className="h-4 w-4 text-purple-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-400">{riskMetrics.sharpeRatio}</div>
                <p className="text-xs text-gray-400">Risk-adjusted return</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Max Drawdown</CardTitle>
                <TrendingDown className="h-4 w-4 text-red-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-400">{riskMetrics.maxDrawdown}%</div>
                <p className="text-xs text-gray-400">Largest decline</p>
              </CardContent>
            </Card>
          </div>

          {/* Portfolio vs Benchmark Chart */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Portfolio vs Benchmark Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={performanceData}>
                    <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "#9CA3AF", fontSize: 12 }} />
                    <YAxis
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: "#9CA3AF", fontSize: 12 }}
                      tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#374151",
                        border: "1px solid #4B5563",
                        borderRadius: "8px",
                        color: "#fff",
                      }}
                      formatter={(value: any, name: any) => [
                        `$${value.toLocaleString()}`,
                        name === "portfolio" ? "Portfolio" : "Benchmark",
                      ]}
                    />
                    <Line type="monotone" dataKey="portfolio" stroke="#06B6D4" strokeWidth={3} dot={false} />
                    <Line
                      type="monotone"
                      dataKey="benchmark"
                      stroke="#9CA3AF"
                      strokeWidth={2}
                      strokeDasharray="5 5"
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="returns" className="space-y-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <BarChart3 className="w-5 h-5 mr-2 text-cyan-400" />
                Monthly Returns
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyReturns}>
                    <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "#9CA3AF", fontSize: 12 }} />
                    <YAxis
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: "#9CA3AF", fontSize: 12 }}
                      tickFormatter={(value) => `${value}%`}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#374151",
                        border: "1px solid #4B5563",
                        borderRadius: "8px",
                        color: "#fff",
                      }}
                      formatter={(value: any) => [`${value}%`, "Monthly Return"]}
                    />
                    <Bar
                      dataKey="returns"
                      fill={(entry: any) => (entry.returns >= 0 ? "#10B981" : "#EF4444")}
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="risk" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-white">{riskMetrics.beta}</div>
                <div className="text-sm text-gray-400 mt-1">Beta</div>
                <div className="text-xs text-gray-500 mt-2">Market sensitivity</div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-white">{riskMetrics.volatility}%</div>
                <div className="text-sm text-gray-400 mt-1">Volatility</div>
                <div className="text-xs text-gray-500 mt-2">Standard deviation</div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-white">{riskMetrics.alpha}%</div>
                <div className="text-sm text-gray-400 mt-1">Alpha</div>
                <div className="text-xs text-gray-500 mt-2">Excess return</div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="sectors" className="space-y-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <PieChartIcon className="w-5 h-5 mr-2 text-purple-400" />
                Sector Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {sectorPerformance.map((sector) => (
                  <div key={sector.sector} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 rounded-full" style={{ backgroundColor: sector.color }} />
                      <div>
                        <div className="font-semibold text-white">{sector.sector}</div>
                        <div className="text-sm text-gray-400">{sector.allocation}% allocation</div>
                      </div>
                    </div>
                    <div className={`text-right ${sector.returns >= 0 ? "text-green-400" : "text-red-400"}`}>
                      <div className="font-bold">
                        {sector.returns >= 0 ? "+" : ""}
                        {sector.returns}%
                      </div>
                      <div className="text-sm">Returns</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
