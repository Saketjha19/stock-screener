"use client"

import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, DollarSign, PieChartIcon, Target, Activity } from "lucide-react"

const portfolioData = {
  totalValue: 245678.5,
  totalInvested: 220000.0,
  totalGainLoss: 25678.5,
  totalGainLossPercent: 11.67,
  dayChange: 3456.78,
  dayChangePercent: 1.43,
}

const allocationData = [
  { name: "Technology", value: 45, amount: 110555.33, color: "#06B6D4" },
  { name: "Healthcare", value: 20, amount: 49135.7, color: "#8B5CF6" },
  { name: "Finance", value: 15, amount: 36851.78, color: "#10B981" },
  { name: "Consumer", value: 12, amount: 29481.42, color: "#F59E0B" },
  { name: "Energy", value: 8, amount: 19654.27, color: "#EF4444" },
]

const performanceData = [
  { date: "Jan", value: 220000 },
  { date: "Feb", value: 225000 },
  { date: "Mar", value: 218000 },
  { date: "Apr", value: 235000 },
  { date: "May", value: 242000 },
  { date: "Jun", value: 245678 },
]

const topHoldings = [
  { symbol: "AAPL", name: "Apple Inc.", shares: 150, value: 26314.5, allocation: 10.7 },
  { symbol: "MSFT", name: "Microsoft Corp.", shares: 80, value: 30308.0, allocation: 12.3 },
  { symbol: "GOOGL", name: "Alphabet Inc.", shares: 120, value: 16585.2, allocation: 6.7 },
  { symbol: "NVDA", name: "NVIDIA Corp.", shares: 60, value: 25973.4, allocation: 10.6 },
  { symbol: "TSLA", name: "Tesla Inc.", shares: 90, value: 22357.8, allocation: 9.1 },
]

export function PortfolioOverview() {
  return (
    <div className="space-y-6">
      {/* Portfolio Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Total Portfolio Value</CardTitle>
            <DollarSign className="h-4 w-4 text-cyan-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">${portfolioData.totalValue.toLocaleString()}</div>
            <p className="text-xs text-gray-400">Invested: ${portfolioData.totalInvested.toLocaleString()}</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Total Gain/Loss</CardTitle>
            {portfolioData.totalGainLoss >= 0 ? (
              <TrendingUp className="h-4 w-4 text-green-400" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-400" />
            )}
          </CardHeader>
          <CardContent>
            <div
              className={`text-2xl font-bold ${portfolioData.totalGainLoss >= 0 ? "text-green-400" : "text-red-400"}`}
            >
              {portfolioData.totalGainLoss >= 0 ? "+" : ""}${portfolioData.totalGainLoss.toLocaleString()}
            </div>
            <p className={`text-xs ${portfolioData.totalGainLoss >= 0 ? "text-green-400" : "text-red-400"}`}>
              {portfolioData.totalGainLoss >= 0 ? "+" : ""}
              {portfolioData.totalGainLossPercent.toFixed(2)}%
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Today's Change</CardTitle>
            {portfolioData.dayChange >= 0 ? (
              <TrendingUp className="h-4 w-4 text-green-400" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-400" />
            )}
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${portfolioData.dayChange >= 0 ? "text-green-400" : "text-red-400"}`}>
              {portfolioData.dayChange >= 0 ? "+" : ""}${portfolioData.dayChange.toLocaleString()}
            </div>
            <p className={`text-xs ${portfolioData.dayChange >= 0 ? "text-green-400" : "text-red-400"}`}>
              {portfolioData.dayChange >= 0 ? "+" : ""}
              {portfolioData.dayChangePercent.toFixed(2)}%
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Diversification</CardTitle>
            <Target className="h-4 w-4 text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{allocationData.length}</div>
            <p className="text-xs text-gray-400">Sectors</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Portfolio Performance Chart */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Activity className="w-5 h-5 mr-2 text-cyan-400" />
              Portfolio Performance (6M)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={performanceData}>
                  <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fill: "#9CA3AF", fontSize: 12 }} />
                  <YAxis
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: "#9CA3AF", fontSize: 12 }}
                    tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#374151",
                      border: "1px solid #4B5563",
                      borderRadius: "8px",
                      color: "#fff",
                    }}
                    formatter={(value: any) => [`$${value.toLocaleString()}`, "Portfolio Value"]}
                  />
                  <Line type="monotone" dataKey="value" stroke="#06B6D4" strokeWidth={3} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Asset Allocation Chart */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <PieChartIcon className="w-5 h-5 mr-2 text-purple-400" />
              Asset Allocation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={allocationData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {allocationData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#374151",
                      border: "1px solid #4B5563",
                      borderRadius: "8px",
                      color: "#fff",
                    }}
                    formatter={(value: any, name: any, props: any) => [
                      `${value}% ($${props.payload.amount.toLocaleString()})`,
                      name,
                    ]}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 space-y-2">
              {allocationData.map((item) => (
                <div key={item.name} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-sm text-gray-300">{item.name}</span>
                  </div>
                  <span className="text-sm text-white">{item.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Holdings */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Top Holdings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {topHoldings.map((holding) => (
              <div key={holding.symbol} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-semibold">{holding.symbol.slice(0, 2)}</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">{holding.symbol}</h4>
                    <p className="text-sm text-gray-400">{holding.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-white">${holding.value.toLocaleString()}</div>
                  <div className="text-sm text-gray-400">
                    {holding.shares} shares • {holding.allocation}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
