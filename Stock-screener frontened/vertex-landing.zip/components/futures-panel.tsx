"use client"

import { Line, LineChart, ResponsiveContainer } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown } from "lucide-react"

const futuresData = [
  {
    name: "S&P 500",
    symbol: "SPX",
    price: 4567.89,
    change: 23.45,
    changePercent: 0.52,
    data: [{ value: 4544 }, { value: 4556 }, { value: 4549 }, { value: 4562 }, { value: 4558 }, { value: 4567 }],
  },
  {
    name: "Euro",
    symbol: "EUR/USD",
    price: 1.0876,
    change: -0.0023,
    changePercent: -0.21,
    data: [
      { value: 1.0899 },
      { value: 1.0887 },
      { value: 1.0892 },
      { value: 1.0881 },
      { value: 1.0885 },
      { value: 1.0876 },
    ],
  },
  {
    name: "Gold",
    symbol: "XAU/USD",
    price: 2034.56,
    change: 12.34,
    changePercent: 0.61,
    data: [{ value: 2022 }, { value: 2028 }, { value: 2025 }, { value: 2031 }, { value: 2029 }, { value: 2034 }],
  },
  {
    name: "Oil",
    symbol: "WTI",
    price: 78.92,
    change: -1.23,
    changePercent: -1.53,
    data: [{ value: 80.15 }, { value: 79.87 }, { value: 80.21 }, { value: 79.45 }, { value: 79.12 }, { value: 78.92 }],
  },
]

export function FuturesPanel() {
  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Futures</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {futuresData.map((future) => (
            <div
              key={future.symbol}
              className="flex items-center justify-between p-4 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
            >
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h4 className="font-semibold text-white">{future.name}</h4>
                    <p className="text-sm text-gray-400">{future.symbol}</p>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-white">
                      {future.price.toFixed(future.symbol.includes("/") ? 4 : 2)}
                    </div>
                    <div
                      className={`text-sm flex items-center ${future.change >= 0 ? "text-green-400" : "text-red-400"}`}
                    >
                      {future.change >= 0 ? (
                        <TrendingUp className="w-3 h-3 mr-1" />
                      ) : (
                        <TrendingDown className="w-3 h-3 mr-1" />
                      )}
                      <span>
                        {future.change >= 0 ? "+" : ""}
                        {future.change.toFixed(future.symbol.includes("/") ? 4 : 2)} (
                        {future.changePercent >= 0 ? "+" : ""}
                        {future.changePercent.toFixed(2)}%)
                      </span>
                    </div>
                  </div>
                </div>

                <div className="h-12">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={future.data}>
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke={future.change >= 0 ? "#10B981" : "#EF4444"}
                        strokeWidth={1.5}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
