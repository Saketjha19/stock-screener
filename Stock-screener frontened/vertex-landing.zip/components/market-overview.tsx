"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Line, LineChart, ResponsiveContainer } from "recharts"
import { TrendingUp, TrendingDown } from "lucide-react"

interface MarketOverviewProps {
  selectedTab: string
  onTabChange: (tab: string) => void
}

const marketData = {
  indices: [
    {
      symbol: "SPX",
      name: "S&P 500",
      price: 4567.89,
      change: 23.45,
      changePercent: 0.52,
      data: [{ value: 4544 }, { value: 4556 }, { value: 4549 }, { value: 4562 }, { value: 4558 }, { value: 4567 }],
    },
    {
      symbol: "DJI",
      name: "Dow Jones",
      price: 38234.78,
      change: 156.34,
      changePercent: 0.41,
      data: [
        { value: 38078 },
        { value: 38156 },
        { value: 38123 },
        { value: 38189 },
        { value: 38210 },
        { value: 38234 },
      ],
    },
    {
      symbol: "IXIC",
      name: "NASDAQ",
      price: 14356.45,
      change: -45.67,
      changePercent: -0.32,
      data: [
        { value: 14402 },
        { value: 14389 },
        { value: 14376 },
        { value: 14365 },
        { value: 14358 },
        { value: 14356 },
      ],
    },
    {
      symbol: "RUT",
      name: "Russell 2000",
      price: 2145.67,
      change: 12.34,
      changePercent: 0.58,
      data: [{ value: 2133 }, { value: 2138 }, { value: 2142 }, { value: 2140 }, { value: 2143 }, { value: 2145 }],
    },
  ],
  futures: [
    {
      symbol: "ES1!",
      name: "E-mini S&P 500",
      price: 4570.25,
      change: 24.5,
      changePercent: 0.54,
      data: [{ value: 4546 }, { value: 4558 }, { value: 4552 }, { value: 4565 }, { value: 4568 }, { value: 4570 }],
    },
    {
      symbol: "NQ1!",
      name: "E-mini NASDAQ",
      price: 15876.75,
      change: -32.25,
      changePercent: -0.2,
      data: [
        { value: 15909 },
        { value: 15895 },
        { value: 15882 },
        { value: 15880 },
        { value: 15878 },
        { value: 15876 },
      ],
    },
    {
      symbol: "GC1!",
      name: "Gold",
      price: 2034.56,
      change: 12.34,
      changePercent: 0.61,
      data: [{ value: 2022 }, { value: 2028 }, { value: 2025 }, { value: 2031 }, { value: 2029 }, { value: 2034 }],
    },
    {
      symbol: "CL1!",
      name: "Crude Oil",
      price: 78.92,
      change: -1.23,
      changePercent: -1.53,
      data: [
        { value: 80.15 },
        { value: 79.87 },
        { value: 80.21 },
        { value: 79.45 },
        { value: 79.12 },
        { value: 78.92 },
      ],
    },
  ],
  bonds: [
    {
      symbol: "US10Y",
      name: "10-Year Treasury",
      price: 4.32,
      change: 0.05,
      changePercent: 1.17,
      data: [{ value: 4.27 }, { value: 4.29 }, { value: 4.3 }, { value: 4.31 }, { value: 4.32 }, { value: 4.32 }],
    },
    {
      symbol: "US30Y",
      name: "30-Year Treasury",
      price: 4.45,
      change: 0.03,
      changePercent: 0.68,
      data: [{ value: 4.42 }, { value: 4.43 }, { value: 4.44 }, { value: 4.44 }, { value: 4.45 }, { value: 4.45 }],
    },
    {
      symbol: "US2Y",
      name: "2-Year Treasury",
      price: 4.67,
      change: -0.02,
      changePercent: -0.43,
      data: [{ value: 4.69 }, { value: 4.68 }, { value: 4.68 }, { value: 4.67 }, { value: 4.67 }, { value: 4.67 }],
    },
    {
      symbol: "DE10Y",
      name: "German 10-Year",
      price: 2.45,
      change: 0.02,
      changePercent: 0.82,
      data: [{ value: 2.43 }, { value: 2.44 }, { value: 2.44 }, { value: 2.45 }, { value: 2.45 }, { value: 2.45 }],
    },
  ],
  forex: [
    {
      symbol: "EUR/USD",
      name: "Euro / US Dollar",
      price: 1.0876,
      change: -0.0023,
      changePercent: -0.21,
      data: [
        { value: 1.0899 },
        { value: 1.0887 },
        { value: 1.0892 },
        { value: 1.0881 },
        { value: 1.0885 },
        { value: 1.0876 },
      ],
    },
    {
      symbol: "USD/JPY",
      name: "US Dollar / Japanese Yen",
      price: 151.23,
      change: 0.45,
      changePercent: 0.3,
      data: [
        { value: 150.78 },
        { value: 150.92 },
        { value: 151.05 },
        { value: 151.18 },
        { value: 151.2 },
        { value: 151.23 },
      ],
    },
    {
      symbol: "GBP/USD",
      name: "British Pound / US Dollar",
      price: 1.2654,
      change: 0.0032,
      changePercent: 0.25,
      data: [
        { value: 1.2622 },
        { value: 1.2635 },
        { value: 1.264 },
        { value: 1.2648 },
        { value: 1.265 },
        { value: 1.2654 },
      ],
    },
    {
      symbol: "USD/CAD",
      name: "US Dollar / Canadian Dollar",
      price: 1.3567,
      change: -0.0045,
      changePercent: -0.33,
      data: [
        { value: 1.3612 },
        { value: 1.3598 },
        { value: 1.3585 },
        { value: 1.3575 },
        { value: 1.357 },
        { value: 1.3567 },
      ],
    },
  ],
}

export function MarketOverview({ selectedTab, onTabChange }: MarketOverviewProps) {
  const data = marketData[selectedTab as keyof typeof marketData]

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader className="pb-0">
        <CardTitle className="text-white">Market Overview</CardTitle>
      </CardHeader>
      <CardContent className="pt-4">
        <Tabs value={selectedTab} onValueChange={onTabChange}>
          <TabsList className="bg-gray-700 border-gray-600 mb-6">
            <TabsTrigger value="indices" className="data-[state=active]:bg-cyan-600">
              Indices
            </TabsTrigger>
            <TabsTrigger value="futures" className="data-[state=active]:bg-cyan-600">
              Futures
            </TabsTrigger>
            <TabsTrigger value="bonds" className="data-[state=active]:bg-cyan-600">
              Bonds
            </TabsTrigger>
            <TabsTrigger value="forex" className="data-[state=active]:bg-cyan-600">
              Forex
            </TabsTrigger>
          </TabsList>

          <TabsContent value={selectedTab} className="space-y-4">
            <div className="space-y-4">
              {data.map((item) => (
                <div
                  key={item.symbol}
                  className="flex items-center justify-between p-4 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <h4 className="font-semibold text-white">{item.name}</h4>
                        <p className="text-sm text-gray-400">{item.symbol}</p>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-white">
                          {selectedTab === "bonds" || selectedTab === "forex"
                            ? item.price.toFixed(4)
                            : item.price.toFixed(2)}
                        </div>
                        <div
                          className={`text-sm flex items-center ${
                            item.change >= 0 ? "text-green-400" : "text-red-400"
                          }`}
                        >
                          {item.change >= 0 ? (
                            <TrendingUp className="w-3 h-3 mr-1" />
                          ) : (
                            <TrendingDown className="w-3 h-3 mr-1" />
                          )}
                          <span>
                            {item.change >= 0 ? "+" : ""}
                            {selectedTab === "bonds" || selectedTab === "forex"
                              ? item.change.toFixed(4)
                              : item.change.toFixed(2)}{" "}
                            ({item.changePercent >= 0 ? "+" : ""}
                            {item.changePercent.toFixed(2)}%)
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="h-12">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={item.data}>
                          <Line
                            type="monotone"
                            dataKey="value"
                            stroke={item.change >= 0 ? "#10B981" : "#EF4444"}
                            strokeWidth={1.5}
                            dot={false}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
