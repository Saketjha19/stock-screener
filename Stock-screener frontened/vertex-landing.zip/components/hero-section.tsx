"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ChevronDown } from "lucide-react"

export function HeroSection() {
  const router = useRouter()

  const scrollToNextSection = () => {
    const element = document.getElementById("platform")
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  }

  const handleGetStarted = () => {
    router.push("/signup")
  }

  return (
    <section
      id="home"
      className="relative min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center overflow-hidden"
    >
      {/* Background gradient effects */}
      <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-purple-500/10"></div>
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div className="text-center lg:text-left">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              Step up into the{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                Financial World
              </span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl">Real-Time Data & Insights at Your Fingertips</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button
                onClick={handleGetStarted}
                size="lg"
                className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white px-8 py-3"
              >
                Get Started
              </Button>
              <Button size="lg" variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-800 px-8 py-3">
                Watch Demo
              </Button>
            </div>
          </div>

          {/* Right content - Mobile mockups */}
          <div className="relative flex justify-center lg:justify-end">
            <div className="relative w-full max-w-lg">
              {/* First phone mockup */}
              <div className="relative transform rotate-12 z-10">
                <div className="bg-gray-800 rounded-3xl p-2 shadow-2xl border border-gray-700">
                  <div className="bg-gray-900 rounded-2xl overflow-hidden">
                    <div className="h-12 bg-gray-800 flex items-center justify-center">
                      <div className="w-16 h-1 bg-gray-600 rounded-full"></div>
                    </div>
                    <div className="p-4 space-y-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-white mb-1">₹2,45,678</div>
                        <div className="text-green-400 text-sm">+12.5% Today</div>
                      </div>
                      <div className="h-32 bg-gradient-to-br from-green-500/20 to-cyan-500/20 rounded-lg flex items-center justify-center">
                        <div className="text-gray-400 text-sm">Portfolio Chart</div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center p-2 bg-gray-800 rounded">
                          <span className="text-white text-sm">AAPL</span>
                          <span className="text-green-400 text-sm">+2.3%</span>
                        </div>
                        <div className="flex justify-between items-center p-2 bg-gray-800 rounded">
                          <span className="text-white text-sm">TSLA</span>
                          <span className="text-red-400 text-sm">-1.2%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Second phone mockup */}
              <div className="absolute top-8 -left-8 transform -rotate-12">
                <div className="bg-gray-800 rounded-3xl p-2 shadow-2xl border border-gray-700">
                  <div className="bg-gray-900 rounded-2xl overflow-hidden">
                    <div className="h-12 bg-gray-800 flex items-center justify-center">
                      <div className="w-16 h-1 bg-gray-600 rounded-full"></div>
                    </div>
                    <div className="p-4 space-y-4">
                      <div className="text-center">
                        <div className="text-lg font-bold text-white mb-1">NIFTY 50</div>
                        <div className="text-cyan-400 text-sm">19,845.20</div>
                      </div>
                      <div className="h-32 bg-gradient-to-br from-cyan-500/20 to-purple-500/20 rounded-lg flex items-center justify-center">
                        <div className="text-gray-400 text-sm">Live Chart</div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="bg-gray-800 p-2 rounded text-center">
                          <div className="text-white text-xs">High</div>
                          <div className="text-green-400 text-sm">19,892</div>
                        </div>
                        <div className="bg-gray-800 p-2 rounded text-center">
                          <div className="text-white text-xs">Low</div>
                          <div className="text-red-400 text-sm">19,756</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll down indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <button
          onClick={scrollToNextSection}
          className="animate-bounce text-gray-400 hover:text-white transition-colors"
          aria-label="Scroll to next section"
        >
          <ChevronDown className="w-6 h-6" />
        </button>
      </div>
    </section>
  )
}
