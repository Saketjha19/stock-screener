"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"
import { TrendingUp, TrendingDown } from "lucide-react"

interface MainChartSectionProps {
  selectedStock: string
  selectedTimeframe: string
  onTimeframeChange: (timeframe: string) => void
}

const stockData = {
  AAPL: {
    name: "Apple Inc.",
    price: 175.43,
    change: 2.34,
    changePercent: 1.35,
    data: {
      "1D": [
        { time: "9:30", price: 173.09 },
        { time: "10:00", price: 174.21 },
        { time: "10:30", price: 173.85 },
        { time: "11:00", price: 175.12 },
        { time: "11:30", price: 174.89 },
        { time: "12:00", price: 175.43 },
      ],
      "1M": [
        { time: "Week 1", price: 168.09 },
        { time: "Week 2", price: 172.21 },
        { time: "Week 3", price: 170.85 },
        { time: "Week 4", price: 175.43 },
      ],
      "3M": [
        { time: "Jan", price: 165.09 },
        { time: "Feb", price: 170.21 },
        { time: "Mar", price: 175.43 },
      ],
      "1Y": [
        { time: "Q1", price: 155.09 },
        { time: "Q2", price: 162.21 },
        { time: "Q3", price: 168.85 },
        { time: "Q4", price: 175.43 },
      ],
      "5Y": [
        { time: "2020", price: 75.09 },
        { time: "2021", price: 110.21 },
        { time: "2022", price: 130.85 },
        { time: "2023", price: 150.12 },
        { time: "2024", price: 175.43 },
      ],
      All: [
        { time: "2010", price: 10.09 },
        { time: "2015", price: 40.21 },
        { time: "2020", price: 75.85 },
        { time: "2024", price: 175.43 },
      ],
    },
  },
  GOOGL: {
    name: "Alphabet Inc.",
    price: 138.21,
    change: 1.89,
    changePercent: 1.39,
    data: {
      "1D": [
        { time: "9:30", price: 136.32 },
        { time: "10:00", price: 137.45 },
        { time: "10:30", price: 137.12 },
        { time: "11:00", price: 138.89 },
        { time: "11:30", price: 138.45 },
        { time: "12:00", price: 138.21 },
      ],
      "1M": [
        { time: "Week 1", price: 132.32 },
        { time: "Week 2", price: 134.45 },
        { time: "Week 3", price: 136.12 },
        { time: "Week 4", price: 138.21 },
      ],
      "3M": [
        { time: "Jan", price: 130.32 },
        { time: "Feb", price: 134.45 },
        { time: "Mar", price: 138.21 },
      ],
      "1Y": [
        { time: "Q1", price: 125.32 },
        { time: "Q2", price: 130.45 },
        { time: "Q3", price: 134.12 },
        { time: "Q4", price: 138.21 },
      ],
      "5Y": [
        { time: "2020", price: 80.32 },
        { time: "2021", price: 100.45 },
        { time: "2022", price: 115.12 },
        { time: "2023", price: 125.89 },
        { time: "2024", price: 138.21 },
      ],
      All: [
        { time: "2010", price: 25.32 },
        { time: "2015", price: 45.45 },
        { time: "2020", price: 80.12 },
        { time: "2024", price: 138.21 },
      ],
    },
  },
  MSFT: {
    name: "Microsoft Corp.",
    price: 378.85,
    change: 4.23,
    changePercent: 1.13,
    data: {
      "1D": [
        { time: "9:30", price: 374.62 },
        { time: "10:00", price: 376.21 },
        { time: "10:30", price: 375.85 },
        { time: "11:00", price: 378.12 },
        { time: "11:30", price: 377.89 },
        { time: "12:00", price: 378.85 },
      ],
      "1M": [
        { time: "Week 1", price: 370.62 },
        { time: "Week 2", price: 372.21 },
        { time: "Week 3", price: 375.85 },
        { time: "Week 4", price: 378.85 },
      ],
      "3M": [
        { time: "Jan", price: 365.62 },
        { time: "Feb", price: 372.21 },
        { time: "Mar", price: 378.85 },
      ],
      "1Y": [
        { time: "Q1", price: 350.62 },
        { time: "Q2", price: 360.21 },
        { time: "Q3", price: 370.85 },
        { time: "Q4", price: 378.85 },
      ],
      "5Y": [
        { time: "2020", price: 180.62 },
        { time: "2021", price: 250.21 },
        { time: "2022", price: 300.85 },
        { time: "2023", price: 340.12 },
        { time: "2024", price: 378.85 },
      ],
      All: [
        { time: "2010", price: 30.62 },
        { time: "2015", price: 80.21 },
        { time: "2020", price: 180.85 },
        { time: "2024", price: 378.85 },
      ],
    },
  },
  NVDA: {
    name: "NVIDIA Corp.",
    price: 432.89,
    change: -5.67,
    changePercent: -1.29,
    data: {
      "1D": [
        { time: "9:30", price: 438.56 },
        { time: "10:00", price: 437.45 },
        { time: "10:30", price: 435.12 },
        { time: "11:00", price: 433.89 },
        { time: "11:30", price: 432.45 },
        { time: "12:00", price: 432.89 },
      ],
      "1M": [
        { time: "Week 1", price: 450.56 },
        { time: "Week 2", price: 445.45 },
        { time: "Week 3", price: 440.12 },
        { time: "Week 4", price: 432.89 },
      ],
      "3M": [
        { time: "Jan", price: 460.56 },
        { time: "Feb", price: 450.45 },
        { time: "Mar", price: 432.89 },
      ],
      "1Y": [
        { time: "Q1", price: 300.56 },
        { time: "Q2", price: 350.45 },
        { time: "Q3", price: 400.12 },
        { time: "Q4", price: 432.89 },
      ],
      "5Y": [
        { time: "2020", price: 50.56 },
        { time: "2021", price: 150.45 },
        { time: "2022", price: 250.12 },
        { time: "2023", price: 350.89 },
        { time: "2024", price: 432.89 },
      ],
      All: [
        { time: "2010", price: 5.56 },
        { time: "2015", price: 25.45 },
        { time: "2020", price: 50.12 },
        { time: "2024", price: 432.89 },
      ],
    },
  },
  TSLA: {
    name: "Tesla Inc.",
    price: 248.42,
    change: -3.21,
    changePercent: -1.27,
    data: {
      "1D": [
        { time: "9:30", price: 251.63 },
        { time: "10:00", price: 250.45 },
        { time: "10:30", price: 249.12 },
        { time: "11:00", price: 248.89 },
        { time: "11:30", price: 248.45 },
        { time: "12:00", price: 248.42 },
      ],
      "1M": [
        { time: "Week 1", price: 260.63 },
        { time: "Week 2", price: 255.45 },
        { time: "Week 3", price: 250.12 },
        { time: "Week 4", price: 248.42 },
      ],
      "3M": [
        { time: "Jan", price: 270.63 },
        { time: "Feb", price: 260.45 },
        { time: "Mar", price: 248.42 },
      ],
      "1Y": [
        { time: "Q1", price: 200.63 },
        { time: "Q2", price: 220.45 },
        { time: "Q3", price: 240.12 },
        { time: "Q4", price: 248.42 },
      ],
      "5Y": [
        { time: "2020", price: 40.63 },
        { time: "2021", price: 120.45 },
        { time: "2022", price: 180.12 },
        { time: "2023", price: 220.89 },
        { time: "2024", price: 248.42 },
      ],
      All: [
        { time: "2010", price: 5.63 },
        { time: "2015", price: 20.45 },
        { time: "2020", price: 40.12 },
        { time: "2024", price: 248.42 },
      ],
    },
  },
}

const summaryCards = [
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    price: 175.43,
    change: 2.34,
    changePercent: 1.35,
  },
  {
    symbol: "NVDA",
    name: "NVIDIA Corp.",
    price: 432.89,
    change: -5.67,
    changePercent: -1.29,
  },
  {
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    price: 138.21,
    change: 1.89,
    changePercent: 1.39,
  },
]

export function MainChartSection({ selectedStock, selectedTimeframe, onTimeframeChange }: MainChartSectionProps) {
  const [activeTab, setActiveTab] = useState(selectedStock)

  const handleTabChange = (value: string) => {
    setActiveTab(value)
  }

  const stock = stockData[activeTab as keyof typeof stockData]
  const chartData = stock?.data[selectedTimeframe as keyof typeof stock.data] || []

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {summaryCards.map((card) => (
          <Card
            key={card.symbol}
            className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors cursor-pointer"
            onClick={() => handleTabChange(card.symbol)}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h3 className="font-bold text-white">{card.symbol}</h3>
                  <p className="text-xs text-gray-400 truncate">{card.name}</p>
                </div>
                {card.change >= 0 ? (
                  <TrendingUp className="w-4 h-4 text-green-400" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-red-400" />
                )}
              </div>

              <div className="space-y-1">
                <div className="text-lg font-bold text-white">${card.price.toFixed(2)}</div>
                <div className={`text-sm flex items-center ${card.change >= 0 ? "text-green-400" : "text-red-400"}`}>
                  <span>
                    {card.change >= 0 ? "+" : ""}
                    {card.change.toFixed(2)}
                  </span>
                  <span className="ml-1">
                    ({card.changePercent >= 0 ? "+" : ""}
                    {card.changePercent.toFixed(2)}%)
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Chart */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="pb-0">
          <div className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0">
            <div>
              <CardTitle className="text-2xl text-white">
                {stock.name} ({activeTab})
              </CardTitle>
              <div className="flex items-center mt-1">
                <span className="text-xl font-bold text-white mr-2">${stock.price.toFixed(2)}</span>
                <span className={`flex items-center text-sm ${stock.change >= 0 ? "text-green-400" : "text-red-400"}`}>
                  {stock.change >= 0 ? (
                    <TrendingUp className="w-4 h-4 mr-1" />
                  ) : (
                    <TrendingDown className="w-4 h-4 mr-1" />
                  )}
                  <span>
                    {stock.change >= 0 ? "+" : ""}
                    {stock.change.toFixed(2)} ({stock.changePercent >= 0 ? "+" : ""}
                    {stock.changePercent.toFixed(2)}%)
                  </span>
                </span>
              </div>
            </div>

            {/* Stock Tabs */}
            <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full md:w-auto">
              <TabsList className="bg-gray-700 border-gray-600">
                <TabsTrigger value="AAPL" className="data-[state=active]:bg-cyan-600">
                  Apple
                </TabsTrigger>
                <TabsTrigger value="GOOGL" className="data-[state=active]:bg-cyan-600">
                  Google
                </TabsTrigger>
                <TabsTrigger value="MSFT" className="data-[state=active]:bg-cyan-600">
                  Microsoft
                </TabsTrigger>
                <TabsTrigger value="NVDA" className="data-[state=active]:bg-cyan-600">
                  NVIDIA
                </TabsTrigger>
                <TabsTrigger value="TSLA" className="data-[state=active]:bg-cyan-600">
                  Tesla
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          {/* Timeframe Selector */}
          <div className="flex justify-end mb-4">
            <Tabs value={selectedTimeframe} onValueChange={onTimeframeChange}>
              <TabsList className="bg-gray-700 border-gray-600">
                <TabsTrigger value="1D" className="data-[state=active]:bg-cyan-600">
                  1D
                </TabsTrigger>
                <TabsTrigger value="1M" className="data-[state=active]:bg-cyan-600">
                  1M
                </TabsTrigger>
                <TabsTrigger value="3M" className="data-[state=active]:bg-cyan-600">
                  3M
                </TabsTrigger>
                <TabsTrigger value="1Y" className="data-[state=active]:bg-cyan-600">
                  1Y
                </TabsTrigger>
                <TabsTrigger value="5Y" className="data-[state=active]:bg-cyan-600">
                  5Y
                </TabsTrigger>
                <TabsTrigger value="All" className="data-[state=active]:bg-cyan-600">
                  All
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Chart */}
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fill: "#9CA3AF", fontSize: 12 }} />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#9CA3AF", fontSize: 12 }}
                  domain={["dataMin - 5", "dataMax + 5"]}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#374151",
                    border: "1px solid #4B5563",
                    borderRadius: "8px",
                    color: "#fff",
                  }}
                  formatter={(value: any) => [`$${value}`, "Price"]}
                />
                <Line
                  type="monotone"
                  dataKey="price"
                  stroke={stock.change >= 0 ? "#10B981" : "#EF4444"}
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
