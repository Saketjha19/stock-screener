"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp } from "lucide-react"

const gainersData = [
  {
    symbol: "NVDA",
    name: "NVIDIA Corp.",
    price: 432.89,
    change: 18.45,
    changePercent: 4.45,
  },
  {
    symbol: "AMD",
    name: "Advanced Micro Devices",
    price: 156.78,
    change: 6.23,
    changePercent: 4.14,
  },
  {
    symbol: "TSLA",
    name: "Tesla Inc.",
    price: 248.42,
    change: 9.87,
    changePercent: 4.14,
  },
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    price: 175.43,
    change: 6.34,
    changePercent: 3.75,
  },
  {
    symbol: "MSFT",
    name: "Microsoft Corp.",
    price: 378.85,
    change: 13.23,
    changePercent: 3.62,
  },
  {
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    price: 138.21,
    change: 4.89,
    changePercent: 3.67,
  },
]

export function GainersPanel() {
  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
          Top Gainers
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {gainersData.map((stock, index) => (
            <div
              key={stock.symbol}
              className="flex items-center justify-between p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors cursor-pointer"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                  {index + 1}
                </div>
                <div>
                  <h4 className="font-semibold text-white">{stock.symbol}</h4>
                  <p className="text-sm text-gray-400 truncate max-w-32">{stock.name}</p>
                </div>
              </div>

              <div className="text-right">
                <div className="font-bold text-white">${stock.price.toFixed(2)}</div>
                <div className="text-green-400 text-sm flex items-center">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  <span>
                    +{stock.change.toFixed(2)} (+{stock.changePercent.toFixed(2)}%)
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
