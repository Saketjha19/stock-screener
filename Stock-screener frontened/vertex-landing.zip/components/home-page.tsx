"use client"

import { useState } from "react"
import { HomeNavbar } from "./home-navbar"
import { LeftPanel } from "./left-panel"
import { MainChartSection } from "./main-chart-section"
import { MarketOverview } from "./market-overview"
import { TopGainersLosers } from "./top-gainers-losers"

export function HomePage() {
  const [selectedStock, setSelectedStock] = useState("AAPL")
  const [selectedTimeframe, setSelectedTimeframe] = useState("1D")
  const [selectedMarketTab, setSelectedMarketTab] = useState("indices")

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <HomeNavbar />

      <div className="flex">
        <LeftPanel onSelectStock={setSelectedStock} />

        <main className="flex-1 p-6 ml-80">
          <div className="space-y-6">
            <MainChartSection
              selectedStock={selectedStock}
              selectedTimeframe={selectedTimeframe}
              onTimeframeChange={setSelectedTimeframe}
            />

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <MarketOverview selectedTab={selectedMarketTab} onTabChange={setSelectedMarketTab} />
              </div>
              <div>
                <TopGainersLosers />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
