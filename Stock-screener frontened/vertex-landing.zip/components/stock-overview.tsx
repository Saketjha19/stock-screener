"use client"

import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { TrendingUp, TrendingDown } from "lucide-react"

const stockData = {
  AAPL: {
    name: "Apple Inc.",
    price: 175.43,
    change: 2.34,
    changePercent: 1.35,
    data: [
      { time: "09:30", price: 173.09 },
      { time: "10:00", price: 174.21 },
      { time: "10:30", price: 173.85 },
      { time: "11:00", price: 175.12 },
      { time: "11:30", price: 174.89 },
      { time: "12:00", price: 175.43 },
    ],
  },
  GOOGL: {
    name: "Alphabet Inc.",
    price: 138.21,
    change: 1.89,
    changePercent: 1.39,
    data: [
      { time: "09:30", price: 136.32 },
      { time: "10:00", price: 137.45 },
      { time: "10:30", price: 137.12 },
      { time: "11:00", price: 138.89 },
      { time: "11:30", price: 138.45 },
      { time: "12:00", price: 138.21 },
    ],
  },
  MSFT: {
    name: "Microsoft Corp.",
    price: 378.85,
    change: 4.23,
    changePercent: 1.13,
    data: [
      { time: "09:30", price: 374.62 },
      { time: "10:00", price: 376.21 },
      { time: "10:30", price: 375.85 },
      { time: "11:00", price: 378.12 },
      { time: "11:30", price: 377.89 },
      { time: "12:00", price: 378.85 },
    ],
  },
}

interface StockOverviewProps {
  selectedStock: string
  onStockSelect: (stock: string) => void
}

export function StockOverview({ selectedStock, onStockSelect }: StockOverviewProps) {
  const stock = stockData[selectedStock as keyof typeof stockData]

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Stock Overview</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={selectedStock} onValueChange={onStockSelect}>
          <TabsList className="bg-gray-700 border-gray-600 mb-6">
            <TabsTrigger value="AAPL" className="data-[state=active]:bg-cyan-600">
              Apple
            </TabsTrigger>
            <TabsTrigger value="GOOGL" className="data-[state=active]:bg-cyan-600">
              Google
            </TabsTrigger>
            <TabsTrigger value="MSFT" className="data-[state=active]:bg-cyan-600">
              Microsoft
            </TabsTrigger>
          </TabsList>

          {Object.entries(stockData).map(([symbol, data]) => (
            <TabsContent key={symbol} value={symbol} className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-white">{data.name}</h3>
                  <p className="text-gray-400">{symbol}</p>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-white">${data.price.toFixed(2)}</div>
                  <div className={`flex items-center ${data.change >= 0 ? "text-green-400" : "text-red-400"}`}>
                    {data.change >= 0 ? (
                      <TrendingUp className="w-4 h-4 mr-1" />
                    ) : (
                      <TrendingDown className="w-4 h-4 mr-1" />
                    )}
                    <span>
                      {data.change >= 0 ? "+" : ""}
                      {data.change.toFixed(2)} ({data.changePercent >= 0 ? "+" : ""}
                      {data.changePercent.toFixed(2)}%)
                    </span>
                  </div>
                </div>
              </div>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.data}>
                    <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fill: "#9CA3AF", fontSize: 12 }} />
                    <YAxis
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: "#9CA3AF", fontSize: 12 }}
                      domain={["dataMin - 1", "dataMax + 1"]}
                    />
                    <Line
                      type="monotone"
                      dataKey="price"
                      stroke={data.change >= 0 ? "#10B981" : "#EF4444"}
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  )
}
