"use client"

import type React from "react"

import { useState } from "react"
import { Search, Calendar, Clock } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

interface LeftPanelProps {
  onSelectStock: (symbol: string) => void
}

const economicEvents = [
  {
    time: "09:30",
    country: "🇺🇸",
    event: "GDP Growth Rate",
    value: "2.1%",
    impact: "high",
  },
  {
    time: "10:00",
    country: "🇪🇺",
    event: "Inflation Rate",
    value: "3.2%",
    impact: "medium",
  },
  {
    time: "11:30",
    country: "🇯🇵",
    event: "Exports - USD",
    value: "$68.2B",
    impact: "high",
  },
  {
    time: "14:00",
    country: "🇬🇧",
    event: "Interest Rate",
    value: "5.25%",
    impact: "high",
  },
  {
    time: "15:30",
    country: "🇨🇦",
    event: "Employment Rate",
    value: "6.1%",
    impact: "medium",
  },
  {
    time: "16:00",
    country: "🇦🇺",
    event: "Trade Balance",
    value: "$2.1B",
    impact: "low",
  },
  {
    time: "17:30",
    country: "🇨🇳",
    event: "Manufacturing PMI",
    value: "50.2",
    impact: "medium",
  },
  {
    time: "18:00",
    country: "🇮🇳",
    event: "Foreign Exchange Reserves",
    value: "$642.5B",
    impact: "medium",
  },
]

const recentSearches = ["AAPL", "MSFT", "GOOGL", "NVDA", "TSLA"]

export function LeftPanel({ onSelectStock }: LeftPanelProps) {
  const [searchTerm, setSearchTerm] = useState("")

  const handleSearch = () => {
    if (searchTerm.trim()) {
      onSelectStock(searchTerm.toUpperCase())
      setSearchTerm("")
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch()
    }
  }

  return (
    <div className="fixed left-0 top-[7.5rem] w-80 h-[calc(100vh-7.5rem)] bg-gray-800 border-r border-gray-700 p-4 overflow-y-auto">
      {/* Search Section */}
      <Card className="bg-gray-700 border-gray-600 mb-6">
        <CardHeader className="pb-3">
          <CardTitle className="text-white">Searched Stock</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex space-x-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search US Stocks"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={handleKeyDown}
                className="pl-10 bg-gray-600 border-gray-500 text-white placeholder-gray-400 focus:border-cyan-400"
              />
            </div>
            <Button onClick={handleSearch} className="bg-cyan-600 hover:bg-cyan-700 text-white">
              <Search className="w-4 h-4" />
            </Button>
          </div>

          {/* Recent Searches */}
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-400">Recent Searches</h3>
            <div className="flex flex-wrap gap-2">
              {recentSearches.map((symbol) => (
                <Button
                  key={symbol}
                  variant="outline"
                  size="sm"
                  onClick={() => onSelectStock(symbol)}
                  className="border-gray-600 text-gray-300 hover:border-cyan-400 hover:text-cyan-400"
                >
                  {symbol}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Economic Calendar */}
      <Card className="bg-gray-700 border-gray-600">
        <CardHeader className="pb-3">
          <CardTitle className="text-white flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-cyan-400" />
            Economic Calendar
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {economicEvents.map((event, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-3 bg-gray-600 rounded-lg hover:bg-gray-500 transition-colors cursor-pointer"
            >
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <Clock className="w-3 h-3 text-gray-400" />
                  <span className="text-xs text-gray-300">{event.time}</span>
                </div>
                <span className="text-lg">{event.country}</span>
              </div>

              <div className="flex-1 mx-3">
                <div className="text-sm text-white font-medium">{event.event}</div>
                <div className="text-xs text-gray-300">{event.value}</div>
              </div>

              <div
                className={`w-2 h-2 rounded-full ${
                  event.impact === "high" ? "bg-red-400" : event.impact === "medium" ? "bg-yellow-400" : "bg-green-400"
                }`}
              />
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
