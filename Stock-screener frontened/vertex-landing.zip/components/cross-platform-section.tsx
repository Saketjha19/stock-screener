export function CrossPlatformSection() {
  return (
    <section id="platform" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
              Invest seamlessly,{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                anywhere, anytime.
              </span>
            </h2>
            <p className="text-xl text-gray-300 mb-8">We work across all your devices so you never miss a moment.</p>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                <span className="text-gray-300">Synchronized across all platforms</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                <span className="text-gray-300">Real-time notifications</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span className="text-gray-300">Secure cloud backup</span>
              </div>
            </div>
          </div>

          {/* Right content - Device mockups */}
          <div className="relative">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Mobile App UI */}
              <div className="bg-gray-800 rounded-2xl p-4 border border-gray-700 transform hover:scale-105 transition-transform duration-300">
                <div className="bg-gray-900 rounded-xl p-4">
                  <div className="text-center mb-4">
                    <div className="text-white font-semibold">Mobile App</div>
                  </div>
                  <div className="space-y-3">
                    <div className="h-20 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-lg flex items-center justify-center">
                      <span className="text-gray-400 text-sm">Trading Interface</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-gray-800 p-2 rounded text-center">
                        <div className="text-green-400 text-sm">Buy</div>
                      </div>
                      <div className="bg-gray-800 p-2 rounded text-center">
                        <div className="text-red-400 text-sm">Sell</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Desktop Dashboard */}
              <div className="bg-gray-800 rounded-2xl p-4 border border-gray-700 transform hover:scale-105 transition-transform duration-300">
                <div className="bg-gray-900 rounded-xl p-4">
                  <div className="text-center mb-4">
                    <div className="text-white font-semibold">Desktop Dashboard</div>
                  </div>
                  <div className="space-y-3">
                    <div className="h-16 bg-gradient-to-r from-green-500/20 to-cyan-500/20 rounded-lg flex items-center justify-center">
                      <span className="text-gray-400 text-sm">Advanced Charts</span>
                    </div>
                    <div className="grid grid-cols-3 gap-1">
                      <div className="bg-gray-800 p-1 rounded text-center">
                        <div className="text-white text-xs">Portfolio</div>
                      </div>
                      <div className="bg-gray-800 p-1 rounded text-center">
                        <div className="text-white text-xs">Watchlist</div>
                      </div>
                      <div className="bg-gray-800 p-1 rounded text-center">
                        <div className="text-white text-xs">Orders</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Person using laptop */}
            <div className="mt-8 bg-gray-800 rounded-2xl p-6 border border-gray-700 transform hover:scale-105 transition-transform duration-300">
              <div className="flex items-center justify-center h-32 bg-gradient-to-br from-cyan-500/10 to-purple-500/10 rounded-lg">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gray-700 rounded-full mx-auto mb-2 flex items-center justify-center">
                    <div className="w-8 h-8 bg-gray-600 rounded-full"></div>
                  </div>
                  <span className="text-gray-400 text-sm">Professional Trading</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
