"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, DollarSign, PieChart, BarChart3, Settings, LogOut, Bell, User } from "lucide-react"

export default function DashboardPage() {
  const [user] = useState({
    name: "John Doe",
    email: "john.doe@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
  })

  const portfolioData = {
    totalValue: "₹2,45,678",
    todayChange: "+₹12,456",
    todayPercentage: "+5.34%",
    isPositive: true,
  }

  const holdings = [
    { symbol: "AAPL", name: "Apple Inc.", value: "₹45,230", change: "+2.3%", isPositive: true },
    { symbol: "TSLA", name: "Tesla Inc.", value: "₹32,100", change: "-1.2%", isPositive: false },
    { symbol: "GOOGL", name: "Alphabet Inc.", value: "₹28,900", change: "+0.8%", isPositive: true },
    { symbol: "MSFT", name: "Microsoft Corp.", value: "₹41,200", change: "+1.5%", isPositive: true },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Navigation */}
      <nav className="bg-gray-900/95 backdrop-blur-sm border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="text-2xl font-bold text-white">
              Vertex
            </Link>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white">
                <Bell className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white">
                <Settings className="w-5 h-5" />
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-gray-300" />
                </div>
                <span className="text-white text-sm">{user.name}</span>
              </div>
              <Link href="/login">
                <Button variant="outline" size="sm" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Welcome back, {user.name.split(" ")[0]}!</h1>
          <p className="text-gray-400">Here's what's happening with your investments today.</p>
        </div>

        {/* Portfolio Overview */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Total Portfolio Value</CardTitle>
              <DollarSign className="h-4 w-4 text-cyan-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{portfolioData.totalValue}</div>
              <p className={`text-xs ${portfolioData.isPositive ? "text-green-400" : "text-red-400"}`}>
                {portfolioData.todayChange} ({portfolioData.todayPercentage}) today
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Today's Performance</CardTitle>
              {portfolioData.isPositive ? (
                <TrendingUp className="h-4 w-4 text-green-400" />
              ) : (
                <TrendingDown className="h-4 w-4 text-red-400" />
              )}
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${portfolioData.isPositive ? "text-green-400" : "text-red-400"}`}>
                {portfolioData.todayPercentage}
              </div>
              <p className="text-xs text-gray-400">
                {portfolioData.isPositive ? "Gain" : "Loss"} of {portfolioData.todayChange}
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Active Holdings</CardTitle>
              <PieChart className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{holdings.length}</div>
              <p className="text-xs text-gray-400">Stocks in portfolio</p>
            </CardContent>
          </Card>
        </div>

        {/* Holdings Table */}
        <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700 mb-8">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <BarChart3 className="w-5 h-5 mr-2 text-cyan-400" />
              Your Holdings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {holdings.map((holding, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-700/30 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-semibold">{holding.symbol.slice(0, 2)}</span>
                    </div>
                    <div>
                      <p className="text-white font-medium">{holding.symbol}</p>
                      <p className="text-gray-400 text-sm">{holding.name}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-medium">{holding.value}</p>
                    <p className={`text-sm ${holding.isPositive ? "text-green-400" : "text-red-400"}`}>
                      {holding.change}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Button className="h-20 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white">
            <div className="text-center">
              <TrendingUp className="w-6 h-6 mx-auto mb-1" />
              <span className="text-sm">Buy Stocks</span>
            </div>
          </Button>
          <Button className="h-20 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white">
            <div className="text-center">
              <TrendingDown className="w-6 h-6 mx-auto mb-1" />
              <span className="text-sm">Sell Stocks</span>
            </div>
          </Button>
          <Button className="h-20 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white">
            <div className="text-center">
              <BarChart3 className="w-6 h-6 mx-auto mb-1" />
              <span className="text-sm">Analytics</span>
            </div>
          </Button>
          <Button className="h-20 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white">
            <div className="text-center">
              <PieChart className="w-6 h-6 mx-auto mb-1" />
              <span className="text-sm">Portfolio</span>
            </div>
          </Button>
        </div>
      </div>
    </div>
  )
}
